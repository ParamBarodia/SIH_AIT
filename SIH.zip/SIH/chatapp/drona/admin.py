from django.contrib import admin
from .models import drona

# Register your models here.
admin.site.register(drona)
